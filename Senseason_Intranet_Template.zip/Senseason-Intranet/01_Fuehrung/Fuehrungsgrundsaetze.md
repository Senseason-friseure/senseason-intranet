# Führungsgrundsätze bei Senseason

1. **Leidenschaft & Leistung** – Wir packen jede Aufgabe mit Begeisterung an und liefern professionelle Ergebnisse.
2. **Herzlichkeit & Respekt** – Freundlichkeit im Umgang mit Kund:innen und Kolleg:innen ist selbstverständlich.
3. **Klare Ziele & Weiterbildung** – Transparente, verständliche Ziele für alle.
4. **Innovationswille** – Mut zu neuen Ideen und laufende Verbesserungen.
5. **Verantwortung & Kritik** – Jede:r übernimmt Verantwortung, Feedback ist willkommen.
6. **Hands-on-Führung** – Führungskräfte arbeiten aktiv in allen Bereichen mit.
