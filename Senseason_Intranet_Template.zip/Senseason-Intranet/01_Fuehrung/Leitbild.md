# Leitbild

Wir wollen der inspirierendste Friseursalon in unserer Region sein – mit Servicequalität, die Kund:innen begeistert, und einem Team, das füreinander einsteht.
