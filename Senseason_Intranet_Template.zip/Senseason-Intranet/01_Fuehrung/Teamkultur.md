# Teamkultur bei Senseason

- Mitarbeiter:innen im Mittelpunkt – Wertschätzung, Anerkennung und Förderung.
- Offene Kommunikation und Transparenz.
- Einbindung in Entscheidungen.
- Empowerment & Fehlerkultur.
