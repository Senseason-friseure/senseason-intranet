# Vision & Werte – Senseason

## Unsere Vision
Senseason ist ein Ort für Kreativität, Freundlichkeit und Qualität – Herzlichkeit, Innovation und höchste Ansprüche stehen im Mittelpunkt.

## Unsere Werte
- **Freude** – Spaß an der Arbeit und an exzellentem Service
- **Freiheit** – Raum für Kreativität und persönliche Entfaltung
- **Harmonie** – Respektvoller Umgang miteinander
- **Vertrauen** – Verlässlichkeit gegenüber Kund:innen und Team
- **Neugier** – Offenheit für Neues
- **Passion** – Leidenschaft für unseren Beruf
