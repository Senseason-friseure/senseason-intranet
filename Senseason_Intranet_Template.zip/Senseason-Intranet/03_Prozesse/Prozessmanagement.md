# Prozessmanagement bei Senseason

## Strukturierte Abläufe
- Alle Prozesse dokumentiert in unserem "Salon-Logbuch".
- 177 Prozessbeschreibungen, 45 Checklisten, 8 Kernprozesse.

## Aufgaben & Zuständigkeiten
- Klare Hauptaufgaben je Position.
- Vertretungsregelungen für Ausfälle.

## Digitale Transparenz
- Mitarbeiter-App mit Wiki, Chat und Umsatzinfos.
- Jederzeit Zugriff auf Prozesse, Vorlagen und Checklisten.

## Kontinuierliche Verbesserung
- Offene Ideenkultur: Jeder kann Vorschläge einbringen.
- Regelmäßige Qualitätszirkel.
