# Qualitätszirkel

- Regelmäßige Treffen zur Verbesserung von Prozessen.
- Analyse von Feedback und Beschwerden.
- Umsetzung von Verbesserungsideen.
