# Senseason Intranet

Willkommen im Senseason-Intranet.  
Dies ist die zentrale Anlaufstelle für alle internen Informationen, Prozesse und Leitlinien.

## Bereiche
- **00_Ueberblick** – Vision, Werte, Organigramm
- **01_Fuehrung** – Führungsgrundsätze, Leitbild, Teamkultur
- **02_Team** – Onboarding, Mitarbeiterprozesse, Rekrutierung
- **03_Prozesse** – Prozessmanagement, Qualitätsstandards
