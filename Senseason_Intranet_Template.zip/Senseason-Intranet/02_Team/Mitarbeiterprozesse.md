# Mitarbeiterprozesse

- Bewerbungs- und Auswahlverfahren.
- Einarbeitungsplan für neue Mitarbeiter:innen.
- Regelmäßige Feedbackgespräche.
