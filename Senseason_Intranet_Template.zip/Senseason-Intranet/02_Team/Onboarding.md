# Onboarding bei Senseason

- Persönliche Begrüßung und Rundgang durch den Salon.
- Einführung in unsere Werte und Führungsgrundsätze.
- Schulung zu Prozessen und Qualitätsstandards.
