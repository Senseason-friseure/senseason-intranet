# Rekrutierung

- Auswahl nach Fachkompetenz und Werte-Fit.
- Schnuppertage mit Teamentscheidung.
