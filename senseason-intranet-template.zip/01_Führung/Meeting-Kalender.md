# Meeting-Kalender

Empfohlene Meetings:
- Wöchentliches Teammeeting (60 min)
- 1:1 mit Mitarbeitern (monatlich, 30 min)
- Quartals-Review (90 min)
