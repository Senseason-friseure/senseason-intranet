# Teammeeting - Protokollvorlage

**Datum:**  
**Teilnehmer:**  
**Agenda:**  

**Ergebnisse / To-dos:**  
- [ ] Beispiel-Aufgabe
