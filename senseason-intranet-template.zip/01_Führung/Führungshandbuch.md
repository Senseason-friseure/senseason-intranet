# Führungshandbuch

Dieses Dokument enthält Führungsgrundsätze, Meeting-Routinen und Verantwortlichkeiten.

## Inhaltsübersicht
- Rollen & Verantwortlichkeiten
- Meeting-Struktur
- Feedback & Entwicklung
