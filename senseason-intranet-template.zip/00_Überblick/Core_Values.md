# Core Values

- Herz und Handwerk
- Ehrliche Beratung
- Qualität & Design
- Teamgeist

Erkläre hier kurz jeden Punkt.
