# Vision & Mission

**Vision**
Beschreibe hier die langfristige Vision von Senseason.

**Mission**
Beschreibe hier die Mission — warum wir täglich besser werden.

> Platzhaltertext — bitte anpassen.
