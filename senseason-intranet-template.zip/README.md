# Senseason Intranet (Template)

Willkommen im Senseason-Intranet Template.  
Diese Struktur dient als Startpunkt für euer internes Wissen.

## Nächste Schritte
1. Inhalte anpassen (Markdown-Dateien direkt editieren).  
2. PDFs und Grafiken in die entsprechenden Ordner hochladen.  
3. Repository privat auf GitHub anlegen und Inhalte hochladen (oder ZIP entpacken und per Upload einfügen).

---  
Dieses Template wurde automatisch generiert. Viel Erfolg beim Aufbau eures Intranets!
