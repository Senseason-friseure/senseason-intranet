# Vidal Sassoon - Basics

Kurze Einführung zu klaren Linien, Präzisionsschnitten und Prinzipien für Schulungszwecke.
