# Lockenspezialistin

Techniken, Produkte (Aveda) und Preislayering für Lockenkunden.
