# Einarbeitungsplan - Erstes Monat

Woche 1:
- Begrüßung & Tour
- Einführung in Systeme (Kasse, Terminbuchung)

Woche 2-4:
- Hands-on Training am Platz
- Feedback-Gespräch nach 2 Wochen
