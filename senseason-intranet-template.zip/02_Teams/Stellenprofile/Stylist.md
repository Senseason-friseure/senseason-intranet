# Stellenprofil - Stylist

**Aufgaben**
- Kundenberatung
- Haarschnitte & Styling

**Fähigkeiten**
- Kundenorientierung
- Technische Fertigkeiten
